<?php 
   

?>

<!DOCTYPE html>
<html>
   <head>
   <title>Home</title>
   </head>
   <body>
      <a href="resister.php">Register</a>
	  <a href="login.php">Login</a>
   </body>
</html>