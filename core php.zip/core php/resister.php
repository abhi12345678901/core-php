<?php ?>
	
<!DOCTYPE html>
<html>
   <head>
   <title>Home</title>
   <style>
   *{
margin:auto;
padding:0;
box-sizing:border-box;
   }
   table{
margin-top:50px;
   }
   td{
border: 1px solid black;
text-align:center;
padding:20px;
   }
#backcolor{
background:yellow;
   }
   </style>
   </head>
   <body>
      
	  <form action="insert.php" method="post">
	  <table>
	  
        <tr> <td>Name: <input type="text" name="name"></td></tr>
        <tr> <td id="backcolor">Email: <input type="email" name="email"></td></tr>
        <tr><td>Password: <input type="password" name="password"></td></tr>
        <tr> <td id="backcolor">Confirm Password: <input type="password" name="confirmpassword"></td></tr>
		<tr><td><button type="submit">Submit</button></td></tr>
		 </table>
	  </form>
	  <table>
	  </table>
   </body>
</html>