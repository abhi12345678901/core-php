<?php
  include('connection.php');
  
     $name =  $_POST['name'];
	 $email = $_POST['email'];
	 $password = $_POST['password'];
	 
	 $sql = "INSERT INTO user(name,email,password) VALUES ('$name','$email','$password')";
	 
	 if(mysqli_query($conn,$sql)){
		 echo "New record inserted successfully.";
	 }
	 else
	 {
	     echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	 }
	 
	 mysqli_close($conn);
?>